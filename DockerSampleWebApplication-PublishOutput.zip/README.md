﻿# Docker ASP.NET SQL Sample Project

Sample ASP.NET project which packages Web Forms, Docker and SQL/Postgres DB connection.

Note - Project created on VS 2017 and .NET Framework 4.5.2